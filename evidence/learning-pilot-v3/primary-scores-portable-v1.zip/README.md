# Smart Swarm primary score replay

Extract this ZIP into a new directory and run the following command using Python 3.11 or later.

```bash
python verify_portable_primary.py --output verified-tables.json
```

The verifier uses the Python standard library. It recomputes the original score rows for the two frozen heads,
seven registered methods and three team sizes. It keeps both F6 alternatives inside their shared source group
and checks equality of the saved policy outputs for the pair. The calibration and independent evaluation cohorts
retain their original split. It weights each underlying scene equally within a team size.

The exported forecasts contain the stored beliefs, decisions and byte counts needed for scoring. Evaluator outcomes
live in a separate file. Reference identities bind this projection to the original frozen archives and score tables.
The full Homebrain study bundle retains the scoped image inputs, wire records, ablations and training details.
Reproducing model inference, full input isolation and physics requires that full study material.
